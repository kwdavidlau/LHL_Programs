class Cellphone < Product
end
